package com.example.kopilate.lisbuah;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class BuahAdapter extends RecyclerView.Adapter<BuahAdapter.ViewHolder> {

    

    // TODO 1 : panggil Layout
   
    private void playAudio(int position) {
        int[] audioitem={R.raw.alpukat,
                        R.raw.apel,
                        R.raw.ceri,
                        R.raw.durian,
                        R.raw.jambu_air,
                        R.raw.manggis,
                        R.raw.strawberry};

        Uri uri = Uri.parse("android.resource://"+getClass().getPackage().getName()+"/"+audioitem[position]);

        MediaPlayer player = new MediaPlayer();
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);

        try {
            player.setDataSource(context, uri);
        }   catch (IOException e){
            e.printStackTrace();
        }

        try {
            player.prepare();
        } catch (IOException e){
            e.printStackTrace();
        }

        player.start();
    }



    // TODO 5 : hitung data
   

    //TODO 2 : deklarasi dan inisialisasi item List
    
    }
}
